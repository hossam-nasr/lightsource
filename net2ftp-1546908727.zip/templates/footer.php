            </div>

            <div id="bottom">
                Copyright &#169; LightSource Inc.
            </div>

        </div>

    </body>

</html>
