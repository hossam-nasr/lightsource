<div>
    <h2><?= $title ?></h2>
    <br>
    <h3><?= $message ?></h3>
    <br>
</div>
<div>
    Go <a href="/">back</a>.
</div>
