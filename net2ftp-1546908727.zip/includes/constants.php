<?php

    /**
     * constants.php
     *
     * Computer Science 50
     * Adapted from Problem Set 7
     *
     * Global constants.
     */

    // database's name
    define("DATABASE", "1018378");

    // database's password
    define("PASSWORD", "hossoalgamed");

    // database's server
    define("SERVER", "localhost");

    // database's username
    define("USERNAME", "1018378");
    
    // secret code for verifying ajax requests
    define("CODE", "55ZYAv9lV2TdA");
    
    $SUFFIXES  = [
		"M", 
		"B",
		"Tr",
		"Quadr",
		"Quint",
		"Sext",
		"Sept",
		"Oct",
		"Non",
		"Dec",
		"Undec",
		"Duodec",
		"Tredec",
		"Quattuordec",
		"Quindec",
		"Sexdec",
		"Septendec",
		"Octodec",
		"Novemdec",
		"Vigint"];

?>
